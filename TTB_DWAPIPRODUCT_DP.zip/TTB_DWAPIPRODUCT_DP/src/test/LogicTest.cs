using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Microsoft.Extensions.Logging;
using System.Data.OracleClient;
using TTB.Logging;
using TTB_DWAPIPRODUCT_DP.Definitions;
using TTB_DWAPIPRODUCT_DP.Logic;

namespace TTB_DWAPIPRODUCT_DP_TEST
{
    [TestClass]
    public class LogicTest: ILogger<TTBLogger>
    {
        private ServiceForTest S { get; }

        public LogicTest() { this.S = this.NewServiceForTest();  }

        TTBLogger NewTestLogger()
        {
            return new TTBLogger(this);
        }

        ServiceForTest NewServiceForTest()
        {
            return new ServiceForTest(this.NewTestLogger(), new Setup(null, null));
        }

        void ILogger.Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
        {
        }

        bool ILogger.IsEnabled(LogLevel logLevel)
        {
            return false;
        }

        IDisposable ILogger.BeginScope<TState>(TState state)
        {
            return null;
        }

        [TestMethod]
        public async Task TestTestMethod()            
        {
            Assert.AreEqual(await this.S.Test(), "It works.");
        }

        [TestMethod]
        public void TestParseDate()
        {
            var d = Service.ParseDateTime("2021-06-30T09:20:00+07:00");
            Assert.AreEqual(d.Year, 2021);
            Assert.AreEqual(d.Month, 06);
            Assert.AreEqual(d.Day, 30);
            Assert.AreEqual(d.Hour, 09);
            Assert.AreEqual(d.Minute, 20);
            Assert.AreEqual(d.Second, 00);
        }

        [TestMethod]
        public void TestFormatStringTakeBeginning()
        {
            Assert.AreEqual("012",        Service.FormatStringTakeBeginning("0123456789", 3));
            Assert.AreEqual("0123456789", Service.FormatStringTakeBeginning("0123456789", 30));
            Assert.AreEqual("012",        Service.FormatStringTakeBeginning("0123456789", 3, ""));
            Assert.AreEqual("0123456789", Service.FormatStringTakeBeginning("0123456789", 30, ""));
        }

        [TestMethod]
        public void TestFormatStringTakeEnding()
        {
            Assert.AreEqual("789",        Service.FormatStringTakeEnding("0123456789", 3));
            Assert.AreEqual("0123456789", Service.FormatStringTakeEnding("0123456789", 30));
            Assert.AreEqual("789",        Service.FormatStringTakeEnding("0123456789", 3, ""));
            Assert.AreEqual("0123456789", Service.FormatStringTakeEnding("0123456789", 30, ""));
        }

        [TestMethod]
        public void TestNewStatementId()
        {
            for (var i = 0; i < 1000; i++)
            {
                Assert.AreEqual(20, Service.NewStatementId("").Length);
            }
        }

        public async Task TestOnRequest(Action<StatementRequest> customize, Action<NotifyRequest> check)
        {
            var downloadUriBase = "https://localhost";
            var r = new StatementRequest()
            {
                request_id = "request_id",
                request_uuid = "request_uuid",
                app_id = "app_id",
                rm_id = "rm_id",
                start_datetime = Service.FormatDateTime(DateTime.Now.AddDays(-100)),
                end_datetime = Service.FormatDateTime(DateTime.Now.AddDays(-50)),
                accounts = new string[1] { "acccount001" },
                create_datetime = Service.FormatDateTime(DateTime.Now.AddDays(-5)),
                language = "EN",
                auxiliaryReferenceId = "AAA",
                callback_url = "https://localhost/callback"
            };
            customize(r);
            var notifyRequest = await this.S.GenerateResponseAndReturnNotifyRequest(r, downloadUriBase);
            check(notifyRequest);
        }

        public async Task TestInvalidRequest(Action<StatementRequest> customize)
        {
            var accounts = new string[] { "001", "002", "003" };
            foreach (var a in accounts)
            {
                this.S.Data.Add(a, Tuple.Create(new StatementAcct(), new StatementTran[0]));
            }
            await this.TestOnRequest(
                custom => 
                {
                    custom.accounts = accounts;
                    customize(custom);
                },
                notify =>
                {
                    Assert.AreEqual(notify.status, Service.NOTIFY_STATUS_FAILURE);

                    #pragma warning disable CS0162 // Unreachable code detected
                    if (Service.SHOW_INVALID_PARAMETERS_DETAIL)
                    {
                        Assert.IsTrue(notify.status_detail.StartsWith("Invalid Input Parameter"));
                    }
                    else
                    {
                        Assert.AreEqual(notify.status_detail, "Invalid Input Parameter");
                    }
                    #pragma warning restore CS0162 // Unreachable code detected

                    Assert.AreEqual(notify.download_url, "");
                    Assert.AreEqual(notify.accounts, accounts);
                });
        }

        [TestMethod]
        public async Task TestInvalidRequest_Missing_request_id()
        {
            await this.TestInvalidRequest(r => r.request_id = "");
        }

        [TestMethod]
        public async Task TestInvalidRequest_Missing_request_uuid()
        {
            await this.TestInvalidRequest(r => r.request_uuid = "");
        }

        [TestMethod]
        public async Task TestInvalidRequest_Missing_rm_id()
        {
            await this.TestInvalidRequest(r => r.rm_id = "");
        }

        [TestMethod]
        public async Task TestInvalidRequest_Missing_language()
        {
            await this.TestInvalidRequest(r => r.language = "");
        }

        [TestMethod]
        public async Task TestInvalidRequest_Missing_callback_url()
        {
            await this.TestInvalidRequest(r => r.callback_url = "");
        }

        [TestMethod]
        public async Task TestInvalidRequest_BadDateRange()
        {
            await this.TestInvalidRequest(r =>
            {
                r.start_datetime = Service.FormatDateTime(DateTime.Now.AddDays(-2000));
                r.end_datetime = Service.FormatDateTime(DateTime.Now.AddDays(-20));
            });
        }

        [TestMethod]
        public async Task TestNoDataRequest()
        {
            var accounts = new string[] { "001", "002", "003" };
            await this.TestOnRequest(
                custom => { custom.accounts = accounts; },
                notify =>
                {
                    Assert.AreEqual(Service.NOTIFY_STATUS_NO_DATA, notify.status);
                    Assert.AreEqual("", notify.status_detail);
                    Assert.AreEqual("", notify.download_url);
                    Assert.AreEqual(accounts, notify.accounts);
                });
        }

        //[TestMethod]
        public async Task TestSuccessRequest()
        {
            var accounts = new string[] { "001", "002", "003" };
            foreach (var a in accounts)
            {
                this.S.Data.Add(a, Tuple.Create(new StatementAcct(), new StatementTran[0]));
            }
            await this.TestOnRequest(
                custom => { custom.accounts = accounts; },
                notify =>
                {
                    Assert.AreEqual(notify.status, Service.NOTIFY_STATUS_SUCCESS);
                    Assert.AreEqual(notify.status_detail, "");
                    Assert.AreNotEqual(notify.download_url ?? "", "");
                    Assert.AreEqual(notify.accounts, accounts);
                });
        }
    }

    [TestClass]
    public class BadDataAccessTest : ILogger<TTBLogger>
    {
        private ServiceForTestBadDataAccess S { get; }

        public BadDataAccessTest() { this.S = this.NewServiceForTest(); }

        TTBLogger NewTestLogger()
        {
            return new TTBLogger(this);
        }

        ServiceForTestBadDataAccess NewServiceForTest()
        {
            return new ServiceForTestBadDataAccess(this.NewTestLogger(), new Setup(null, null));
        }

        void ILogger.Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
        {
        }

        bool ILogger.IsEnabled(LogLevel logLevel)
        {
            return false;
        }

        IDisposable ILogger.BeginScope<TState>(TState state)
        {
            return null;
        }
    }

    class FakeDataAccess : DataAccess
    {
        public FakeDataAccess(Setup setup): base(setup) {}
        public override async Task<IDbConnection> NewConnection()
        {
            return await Task.FromResult<IDbConnection>(null);
        }
        public override async Task UsingDb(Func<IDbConnection, Task> f)
        {
            await f(null);
        }
        public override async Task<T> FromDb<T>(Func<IDbConnection, Task<T>> f)
        {
            return await f(null);
        }
    }

    class BadDataAccess : DataAccess
    {
        public BadDataAccess(Setup setup) : base(setup) { }
        public override string GetConnectionString()
        {
            return "Data Source=localhost:5555/invalid;User Id=invalid;Password=invalid";
        }
    }

    class ServiceForTest : Service
    {
        public Dictionary<string, Tuple<StatementAcct, StatementTran[]>> Data { get; set; }
        public ServiceForTest(TTBLogger logger, Setup setup) : base(logger, setup, new FakeDataAccess(setup))
        {
            this.Data = new Dictionary<string, Tuple<StatementAcct, StatementTran[]>>();
        }
        protected override StatementAcct GetStatementAcct(IDbConnection c, string custId, string accountId, DateTime? start, DateTime? end, string language)
        {
            if (this.Data.TryGetValue(accountId, out Tuple<StatementAcct, StatementTran[]> found))
            {
                return found.Item1;
            }
            else return null;
        }
        protected override IEnumerable<StatementTran> QueryStatementTran(IDbConnection c, string accountId, DateTime? start, DateTime? end)
        {
            if (this.Data.TryGetValue(accountId, out Tuple<StatementAcct, StatementTran[]> found))
            {
                return found.Item2;
            }
            else return Enumerable.Empty<StatementTran>();
        }
        public override Task<DownloadResponse> GenerateResponseToStorage(StatementRequest request)
        {
            return base.GenerateResponse(request);
        }
    }

    class ServiceForTestBadDataAccess : Service
    {
        public Dictionary<string, Tuple<StatementAcct, StatementTran[]>> Data { get; set; }
        public ServiceForTestBadDataAccess(TTBLogger logger, Setup setup) : base(logger, setup, new BadDataAccess(setup)) { }
    }
}
