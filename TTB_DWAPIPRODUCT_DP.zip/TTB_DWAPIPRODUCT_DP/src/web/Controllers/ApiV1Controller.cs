using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using DalSoft.Hosting.BackgroundQueue;
using TTB.Logging;
using TTB_DWAPIPRODUCT_DP.Definitions;

namespace TTB_DWAPIPRODUCT_DP.Controllers
{
    [Route(API_BASE_ROUTE)]
    public class ApiV1Controller : Controller
    {
        internal const string API_BASE_ROUTE = "api/v1";
        internal const string API_DWH_AS_STATEMENT = "dwh_as_statement";
        internal const string API_DOWNLOAD_STATEMENT = "download_statement";
        internal readonly Logic.Service service;
        internal readonly TTBLogger logger;
        internal readonly BackgroundQueue queue;
        public ApiV1Controller(BackgroundQueue queue, TTBLogger logger, Logic.Service service)
        {
            this.queue = queue;
            this.logger = logger;
            this.service = service;
        }
        public static string GetUri(HttpRequest request, string relativeUri)
        {
            /* adapted from https://stackoverflow.com/a/50964456/77996 */
            UriHelper.FromAbsolute(
                request.GetDisplayUrl(),
                out string scheme,
                out HostString host,
                out PathString path,
                out QueryString query,
                out FragmentString fragment);
            var pathText = path.ToString();
            var newPath = pathText.Substring(0, pathText.LastIndexOf("/") + 1) + relativeUri;
            return UriHelper.BuildAbsolute(
                scheme: scheme,
                host: host,
                path: newPath);
        }
        [HttpPost, Route(API_DWH_AS_STATEMENT)]
        public async Task DwhAsStatement([FromBody] StatementRequest request)
        {
            try
            {
                await this.logger.TTBLogInbound(this.Request, null, null, request.request_uuid, request.GetLoggingPayload(), async () =>
                {
                    await this._DwhAsStatement(request);
                    return Task.FromResult(true);
                });
            }
            catch (Exception e)
            {
                this.logger.TTBLogError(nameof(DwhAsStatement), null, request.request_uuid, API_DWH_AS_STATEMENT, e, request, null);
                throw e;
            }
        }
        internal async Task _DwhAsStatement(StatementRequest request, HttpRequest httpRequest = null)
        {
            if (httpRequest == null) httpRequest = this.Request;
            var downloadUriBase = GetUri(httpRequest, API_DOWNLOAD_STATEMENT);
            this.queue.Enqueue(async cancellation =>
            {
                await this.service.dwh_as_statement(request, downloadUriBase);
            });
            await Task.FromResult(true);
        }
        [HttpGet, Route(API_DOWNLOAD_STATEMENT)]
        public async Task<ContentResult> DownloadStatement([FromQuery] DownloadRequest request)
        {
            try
            {
                return await this.logger.TTBLogInbound(this.Request, null, null, request.request_uuid, request.GetLoggingPayload(), async () =>
                {
                    var content = this.Content(await this.service.DownloadStatementContent(request), Logic.Service.CONTENT_TYPE_JSON);
                    return await Task.FromResult(content);
                });
            }
            catch (Exception e)
            {
                this.logger.TTBLogError(nameof(DownloadStatement), null, request.request_uuid, API_DOWNLOAD_STATEMENT, e, request, null);
                throw e;
            }
        }
    }
}
