﻿using System.Web;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using DalSoft.Hosting.BackgroundQueue;
using TTB.Logging;
using TTB_DWAPIPRODUCT_DP.Definitions;

namespace TTB_DWAPIPRODUCT_DP.Controllers
{
    [ApiExplorerSettings(IgnoreApi = true)]
    [Route(API_BASE_ROUTE)]
    public class ApiV1ControllerForTest : Controller
    {
        const string API_BASE_ROUTE = ApiV1Controller.API_BASE_ROUTE;
        const string API_DWH_AS_STATEMENT = ApiV1Controller.API_DWH_AS_STATEMENT;
        const string API_NOTIFY_MOCKUP = "notify_mockup";
        const string API_ADHOC = "adhoc";
        const string API_ADHOC2 = "adhoc2";
        private readonly ApiV1Controller peer;
        internal readonly Logic.Service service;
        internal readonly TTBLogger logger;
        private readonly IHostingEnvironment env;
        public ApiV1ControllerForTest(BackgroundQueue queue, TTBLogger logger, Logic.Service service, IHostingEnvironment env)
        {
            this.peer = new ApiV1Controller(queue, logger, service);
            this.service = this.peer.service;
            this.logger = this.peer.logger;
            this.env = env;
        }
        protected bool IsDev() { return this.env.IsDevelopment(); }
        [HttpGet, Route(API_DWH_AS_STATEMENT)]
        public async Task<ActionResult> DwhAsStatementGet([FromQuery] StatementRequest request)
        {
            if (!this.IsDev()) return await Task.FromResult(this.NotFound());
            return await this.logger.TTBLogInbound(this.Request, null, null, request.request_uuid, request.GetLoggingPayload(), async () =>
            {
                await this.peer._DwhAsStatement(request, this.Request);
                return this.Ok();
            });
        }
        [HttpPost, Route(API_NOTIFY_MOCKUP)]
        public async Task<ActionResult> NotifyMockup([FromBody] NotifyRequest request)
        {
            return await this.logger.TTBLogInbound(this.Request, null, null, request.request_uuid, request.GetLoggingPayload(), async () =>
            {
                System.Console.WriteLine("--- Notified ---");
                System.Console.WriteLine($"accounts      : {string.Join(", ", request.accounts)}");
                System.Console.WriteLine($"download_url  : {request.download_url}");
                System.Console.WriteLine($"status        : {request.status}");
                System.Console.WriteLine($"status_detail : {request.status_detail}");
                System.Console.WriteLine("===");
                return await Task.FromResult(this.Ok());
            });
        }
        [HttpGet, Route(API_NOTIFY_MOCKUP)]
        public async Task<ActionResult> NotifyMockupGet([FromQuery] NotifyRequest request)
        {
            if (!this.IsDev()) return await Task.FromResult(this.NotFound());
            return await this.logger.TTBLogInbound(this.Request, null, null, request.request_uuid, request.GetLoggingPayload(), async () =>
            {
                return await this.NotifyMockup(request);
            });
        }
        private static void SanitizeStatementRequestFromQuery(StatementRequest request)
        {
            // When put as url parameter, Plus (+) sign will become space.
            if (request.start_datetime != null) request.start_datetime = request.start_datetime.Replace(" ", "+");
            if (request.end_datetime != null) request.end_datetime = request.end_datetime.Replace(" ", "+");
            if (request.create_datetime != null) request.create_datetime = request.create_datetime.Replace(" ", "+");
        }
        [HttpGet, Route(API_ADHOC)]
        public async Task<ActionResult<DownloadResponse>> Adhoc([FromQuery] StatementRequest request)
        {
            if (!this.IsDev()) return await Task.FromResult(this.NotFound());
            SanitizeStatementRequestFromQuery(request);
            return await this.service.GenerateResponse(request);
        }
        [HttpGet, Route(API_ADHOC2)]
        public async Task<ActionResult<NotifyRequest>> Adhoc2([FromQuery] StatementRequest request)
        {
            if (!this.IsDev()) return await Task.FromResult(this.NotFound());
            SanitizeStatementRequestFromQuery(request);
            var downloadUriBase = API_NOTIFY_MOCKUP;
            return await this.service.GenerateResponseAndReturnNotifyRequest(request, downloadUriBase);
        }
        [HttpGet, Route("SqlStatementAcct")]
        public async Task<ActionResult<string>> SqlStatementAcct()
        {
            if (!this.IsDev()) return await Task.FromResult(this.NotFound());
            return Logic.StatementAcctExtension.GetSql();
        }
        [HttpGet, Route("SqlStatementTran")]
        public async Task<ActionResult<string>> SqlStatementTran()
        {
            if (!this.IsDev()) return await Task.FromResult(this.NotFound());
            return Logic.StatementTranExtension.GetSql();
        }
        [HttpGet, Route("VW_DP_STMT_ACCT")]
        public async Task<ActionResult<string>> VW_DP_STMT_ACCT()
        {
            if (!this.IsDev()) return await Task.FromResult(this.NotFound());
            return Logic.StatementAcctExtension.GetViewSql();
        }
        [HttpGet, Route("VW_DP_STMT_TRAN")]
        public async Task<ActionResult<string>> VW_DP_STMT_TRAN()
        {
            if (!this.IsDev()) return await Task.FromResult(this.NotFound());
            return Logic.StatementTranExtension.GetViewSql();
        }
        [HttpGet, Route("test")]
        public async Task<ActionResult<string>> Test()
        {
            return await this.service.Test();
        }
        [HttpGet, Route("encrypt")]
        public async Task<ActionResult<string>> Encrypt()
        {
            var s = HttpUtility.UrlDecode(this.Request.QueryString.Value.Substring(1));
            return await this.service.Encrypt(s);
        }
        [HttpGet, Route("decrypt")]
        public async Task<ActionResult<string>> Decrypt()
        {
            if (!this.IsDev()) return await Task.FromResult(this.NotFound());
            var s = HttpUtility.UrlDecode(this.Request.QueryString.Value.Substring(1));
            return await this.service.Decrypt(s);
        }
    }
}
