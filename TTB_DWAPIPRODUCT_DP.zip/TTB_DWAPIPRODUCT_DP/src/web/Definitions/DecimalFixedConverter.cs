﻿using System;
using System.Linq;
using System.Globalization;
using Newtonsoft.Json;

namespace TTB_DWAPIPRODUCT_DP.Definitions
{
    public class DecimalFixedConverter: JsonConverter
    {
        private readonly string format;
        public DecimalFixedConverter(int digits)
        {
            var nnn = string.Concat(Enumerable.Repeat('0', digits));
            this.format = $"{{0:0.{nnn}}}";
        }
        public override bool CanConvert(Type objectType)
        {
            return objectType == typeof(decimal) || objectType == typeof(decimal?);
        }
        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            var optional = (value as decimal?);
            if (! optional.HasValue)
            {
                writer.WriteRaw("null");
            }
            else
            {
                writer.WriteRawValue(string.Format(CultureInfo.InvariantCulture, this.format, optional.Value));
            }
        }
        public override bool CanRead => false;
        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            throw new NotImplementedException();
        }
    }
}
