using System.Collections.Generic;
using Newtonsoft.Json;

namespace TTB_DWAPIPRODUCT_DP.Definitions
{
    public class DownloadRequest
    {
        #pragma warning disable IDE1006
        public string request_id { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string request_uuid { get; set; }
        public string app_id { get; set; }
        public string rm_id { get; set; }
        public string auxiliaryReferenceId { get; set; }
        #pragma warning restore IDE1006
        static void AddPayloadValue(Dictionary<string, object> dic, string name, object value)
        {
            if (value != null) dic.Add(name, value);
        }
        public Dictionary<string, object> GetLoggingValues()
        {
            var r = new Dictionary<string, object>();
            AddPayloadValue(r, nameof(request_id), this.request_id);
            AddPayloadValue(r, nameof(rm_id), this.rm_id);
            AddPayloadValue(r, nameof(auxiliaryReferenceId), this.auxiliaryReferenceId);
            AddPayloadValue(r, nameof(request_uuid), this.request_uuid);
            return r;
        }
        public string GetLoggingPayload()
        {
            return JsonConvert.SerializeObject(this.GetLoggingValues());
        }
    }
}