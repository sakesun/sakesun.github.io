using System.Collections.Generic;

namespace TTB_DWAPIPRODUCT_DP.Definitions
{
    public class DownloadResponse
    {
        #pragma warning disable IDE1006
        public Statement[] AccountStatement { get; set; }
        #pragma warning restore IDE1006
        public string GetLoggingPayload()
        {
            if (this.AccountStatement == null || this.AccountStatement.Length == 0) return "[]";
            var items = new List<string>();
            foreach (var acct in this.AccountStatement)
            {
                var entries = acct.statementEntries == null ? 0 : acct.statementEntries.Length;
                items.Add($"{{ \"{acct.accountId}\" [{entries} entries] }}");
            }
            return $"[{string.Join(", ", items)}]";
        }
    }
}