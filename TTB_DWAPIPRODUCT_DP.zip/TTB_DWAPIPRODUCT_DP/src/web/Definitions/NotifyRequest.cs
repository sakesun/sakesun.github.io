using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace TTB_DWAPIPRODUCT_DP.Definitions
{
    public class NotifyRequest
    {
        #pragma warning disable IDE1006
        public string request_id { get; set; }
        public string auxiliaryReferenceId { get; set; }
        public string download_url { get; set; }
        public string status { get; set; }
        public string status_detail { get; set; }
        public string[] accounts { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string request_uuid { get; set; }
        #pragma warning restore IDE1006
        static void AddPayloadValue(Dictionary<string, object> dic, string name, object value)
        {
            if (value != null) dic.Add(name, value);
        }
        public Dictionary<string, object> GetLoggingValues()
        {
            var r = new Dictionary<string, object>();
            AddPayloadValue(r, nameof(request_id), this.request_id);
            AddPayloadValue(r, nameof(auxiliaryReferenceId), this.auxiliaryReferenceId);
            AddPayloadValue(r, nameof(download_url), this.download_url);
            AddPayloadValue(r, nameof(status), this.status);
            AddPayloadValue(r, nameof(status_detail), this.status_detail);
            AddPayloadValue(r, nameof(accounts), this.accounts);
            return r;
        }
        public string GetLoggingPayload()
        {
            return JsonConvert.SerializeObject(this.GetLoggingValues());
        }

        public class NotifyWithException: Exception
        {
            public NotifyRequest NotifyRequest { get; set; }
        }
    }
}