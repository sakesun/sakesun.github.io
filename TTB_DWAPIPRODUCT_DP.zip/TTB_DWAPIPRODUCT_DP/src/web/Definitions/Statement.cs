using System.Text.Json;
using Newtonsoft.Json;

namespace TTB_DWAPIPRODUCT_DP.Definitions
{
    /* Note: to force null value inclusion 
     *   [JsonProperty(NullValueHandling = NullValueHandling.Include)] 
     */

    public class Statement
    {
        #pragma warning disable IDE1006
        public string creationDateTime { get; set; }
        public string statementId { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string auxiliaryReferenceId { get; set; }
        public string institutionName { get; set; }
        public string accountId { get; set; }
        public string ownerType { get; set; }
        public string accountType { get; set; }
        public string accountSubType { get; set; }
        public string accountStatus { get; set; }
        public string accountName { get; set; }
        [JsonConverter(typeof(DecimalFixedConverter), 2)]
        public decimal? lastLedgerBalanceAmount { get; set; }
        public string lastLedgerBalanceCurrency { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore), JsonConverter(typeof(DecimalFixedConverter), 2)]
        public decimal? lastAvailableBalanceAmount { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string lastAvailableBalanceCurrency { get; set; }
        public string startDateTime { get; set; }
        public string endDateTime { get; set; }
        public int numberofTotalItems { get; set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string statementDescription { get; set; }
        [JsonConverter(typeof(DecimalFixedConverter), 2)]
        public decimal? creditLimit { get; set; }
        public Entry[] statementEntries { get; set; }

        public class Entry
        {
            public string bookingDateTime { get; set; }
            [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
            public string valueDateTime { get; set; }
            public string bankTransactionCode { get; set; }
            public string proprietaryBankTransactionCode { get; set; }
            public string proprietaryBankTransactionDescription { get; set; }
            public string creditDebitIndicator { get; set; }
            [JsonConverter(typeof(DecimalFixedConverter), 2)]
            public decimal? amount { get; set; }
            public string amountCurrency { get; set; }
            [JsonConverter(typeof(DecimalFixedConverter), 2)]
            public decimal? balance { get; set; }
            public string balanceCurrency { get; set; }
        }
        #pragma warning restore IDE1006
    }
}