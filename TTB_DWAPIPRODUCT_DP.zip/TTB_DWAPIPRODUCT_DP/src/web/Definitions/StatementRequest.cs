using System;
using System.Linq;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace TTB_DWAPIPRODUCT_DP.Definitions
{
    public class StatementRequest
    {
        #pragma warning disable IDE1006
        public string request_id { get; set; }
        public string request_uuid { get; set; }
        public string app_id { get; set; }
        public string rm_id { get; set; }
        public string start_datetime { get; set; }
        public string end_datetime { get; set; }
        public string[] accounts { get; set; }
        public string create_datetime { get; set; }
        public string language { get; set; }
        public string auxiliaryReferenceId { get; set; }
        public string callback_url { get; set; }
        #pragma warning restore IDE1006

        static bool CheckMandatoryString(List<string> invalids, string name, string value)
        {
            if (!string.IsNullOrWhiteSpace(value)) return true;
            invalids.Add($"Invalid \"{name}\"");
            return false;
        }

        static DateTime? CheckDateTime(List<string> invalids, string name, string value)
        {
            try
            {
                return Logic.Service.ParseDateTime(value);
            }
            catch
            {
                invalids.Add($"Invalid \"{name}\"");
                return null;
            }
        }

        static DateTime? CheckMandatoryDateTime(List<string> invalids, string name, string value)
        {
            if (!CheckMandatoryString(invalids, name, value)) return null;
            return CheckDateTime(invalids, name, value);
        }

        const bool CHECK_DATE_RANGE = true;
        const bool CHECK_DATE_AGE = false;

        static bool CheckStartEnd(List<string> invalids, string start_datetime, string end_datetime, int? statementRange)
        {
            var dStart = CheckMandatoryDateTime(invalids, nameof(start_datetime), start_datetime);
            var dEnd = CheckMandatoryDateTime(invalids, nameof(end_datetime), end_datetime);
            if ((!dStart.HasValue) || (!dEnd.HasValue)) return false;
            if (!statementRange.HasValue) return true;
            var now = DateTime.Now;
            var startPastDays = (now - dStart.Value).TotalDays;
            var endPastDays = (now - dEnd.Value).TotalDays;
            var invalid = false;
            if (CHECK_DATE_RANGE)
            {
                #pragma warning disable 0162
                if ((dEnd.Value - dStart.Value).TotalDays > statementRange.Value)
                {
                    invalids.Add($"Invalid start/end range");
                    invalid = true;
                }
                #pragma warning restore 0162
            }
            if (CHECK_DATE_AGE)
            {
                #pragma warning disable 0162
                if (startPastDays > statementRange.Value)
                {
                    invalids.Add($"Invalid \"{nameof(start_datetime)}\"");
                    invalid = true;
                }
                if (endPastDays > statementRange.Value)
                {
                    invalids.Add($"Invalid \"{nameof(end_datetime)}\"");
                    invalid = true;
                }
                #pragma warning restore 0162
            }
            return invalid;
        }

        public List<string> FindInvalids(int? maxAccounts, int? statementRange)
        {
            var r = new List<string>();
            CheckMandatoryString(r, nameof(this.request_id),   this.request_id);
            CheckMandatoryString(r, nameof(this.request_uuid), this.request_uuid);
            CheckMandatoryString(r, nameof(this.rm_id),        this.rm_id);
            CheckMandatoryString(r, nameof(this.language),     this.language);
            CheckMandatoryString(r, nameof(this.callback_url), this.callback_url);
            if (this.accounts == null 
                || this.accounts.Length == 0 
                || this.accounts.Any(a => string.IsNullOrWhiteSpace(a)))
            {
                r.Add($"Invalid \"{nameof(this.accounts)}\"");
            }
            else
            {
                if (maxAccounts.HasValue && this.accounts.Length > maxAccounts.Value)
                {
                    r.Add($"Invalid \"{nameof(this.accounts)}\"");
                }
            }
            CheckMandatoryDateTime(r, nameof(this.create_datetime), this.create_datetime);
            CheckStartEnd(r, this.start_datetime, this.end_datetime, statementRange);
            return r;
        }

        static void AddPayloadValue(Dictionary<string, object> dic, string name, object value)
        {
            if (value != null) dic.Add(name, value);
        }

        public Dictionary<string, object> GetLoggingValues()
        {
            var r = new Dictionary<string, object>();
            AddPayloadValue(r, nameof(request_id), this.request_id);
            AddPayloadValue(r, nameof(app_id), this.app_id);
            AddPayloadValue(r, nameof(rm_id), this.rm_id);
            AddPayloadValue(r, nameof(start_datetime), this.start_datetime);
            AddPayloadValue(r, nameof(end_datetime), this.end_datetime);
            AddPayloadValue(r, nameof(accounts), this.accounts);
            AddPayloadValue(r, nameof(create_datetime), this.create_datetime);
            AddPayloadValue(r, nameof(language), this.language);
            AddPayloadValue(r, nameof(auxiliaryReferenceId), this.auxiliaryReferenceId);
            AddPayloadValue(r, nameof(callback_url), this.callback_url);
            return r;
        }

        public string GetLoggingPayload()
        {
            return JsonConvert.SerializeObject(this.GetLoggingValues());
        }
    }
}
