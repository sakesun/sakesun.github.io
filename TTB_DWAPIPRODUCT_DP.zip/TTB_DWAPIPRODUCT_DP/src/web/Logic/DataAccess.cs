﻿using System;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Data;
using System.Data.OracleClient;

namespace TTB_DWAPIPRODUCT_DP.Logic
{
    public class DataAccess
    {
        private Setup setup;
        private string _ConnectionString = null;
        public DataAccess(Setup setup)
        {
            this.setup = setup;
        }
        public bool CheckField {  get { return this.setup.CheckField; } }
        private const string PLAIN_PREFIX = "PLAIN:";
        public virtual string GetConnectionString() {
            if (this._ConnectionString == null)
            {
                var s = this.setup.Options.DWHConnection;
                if (!string.IsNullOrEmpty(s))
                {
                    this._ConnectionString = s.StartsWith(PLAIN_PREFIX)
                        ? s.Substring(PLAIN_PREFIX.Length)
                        : AESEncryption.Decrypt(s, setup.Options.AesPassword, setup.Options.AesSalt);
                }
            }
            return this._ConnectionString;
        }
        public virtual async Task<IDbConnection> NewConnection()
        {
            Environment.SetEnvironmentVariable("NLS_LANG", ".UTF8");
            var c = new OracleConnection(this.GetConnectionString());
            try
            {
                c.Open();
                return await Task.FromResult(c);
            } catch(Exception e)
            {
                try { if (c.State == ConnectionState.Open) c.Close(); } catch { }
                throw e;
            }
        }
        public virtual async Task UsingDb(Func<IDbConnection, Task> f)
        {
            var c = await NewConnection();
            try
            {
                await f(c);
            }
            finally
            {
                try { c.Close(); } catch { }
            }
        }
        public virtual async Task<T> FromDb<T>(Func<IDbConnection, Task<T>> f)
        {
            var c = await NewConnection();
            try
            {
                return await f(c);
            }
            finally
            {
                try { c.Close(); } catch { }
            }
        }
        public IDbDataParameter AddStringParameter(IDbCommand cmd, string name, string value)
        {
            var p = cmd.CreateParameter();
            p.DbType = DbType.String;
            p.ParameterName = name;
            p.Value = value;
            cmd.Parameters.Add(p);
            return p;
        }
        public IDbDataParameter AddDateParameter(IDbCommand cmd, string name, DateTime? value)
        {
            var p = cmd.CreateParameter();
            p.DbType = DbType.Date;
            p.ParameterName = name;
            p.Value = value.HasValue ? (value.Value as object) : null;
            cmd.Parameters.Add(p);
            return p;
        }
        public string GetStringField(IDataReader r, int i, string name)
        {
            if (this.CheckField) Debug.Assert(name == r.GetName(i));
            return r.IsDBNull(i) ? null : r.GetString(i);
        }
        public DateTime? GetDateField(IDataReader r, int i, string name)
        {
            if (this.CheckField) Debug.Assert(name == r.GetName(i));
            return r.IsDBNull(i) ? (DateTime?)null : r.GetDateTime(i);
        }
        public Decimal? GetDecimalField(IDataReader r, int i, string name)
        {
            if (this.CheckField) Debug.Assert(name == r.GetName(i));
            return r.IsDBNull(i) ? (Decimal?)null : r.GetDecimal(i);
        }
        private Tuple<string, Type> GetColumnNameAndType(IDataReader r, int i)
        {
            var s = r.GetSchemaTable();
            var row = s.Rows[i];
            var columnName = row["ColumnName"] as string;
            var dateTypeName = row["DataType"] as Type;
            return Tuple.Create(columnName, dateTypeName);
        }
        public void CheckStringField(IDataReader r, int i, string name)
        {
            if (this.CheckField)
            {
                Debug.Assert(name == r.GetName(i));
                var nt = GetColumnNameAndType(r, i);
                Debug.Assert(nt.Item1 == name);
                Debug.Assert(nt.Item2 == typeof(string));
            }
        }
        public void CheckDateField(IDataReader r, int i, string name)
        {
            if (this.CheckField)
            {
                Debug.Assert(name == r.GetName(i));
                var nt = GetColumnNameAndType(r, i);
                Debug.Assert(nt.Item1 == name);
                Debug.Assert(nt.Item2 == typeof(DateTime));
            }
        }
        public void CheckDecimalField(IDataReader r, int i, string name)
        {
            if (this.CheckField)
            {
                Debug.Assert(name == r.GetName(i));
                var nt = GetColumnNameAndType(r, i);
                Debug.Assert(nt.Item1 == name);
                Debug.Assert(nt.Item2 == typeof(Decimal));
            }
        }
    }
}
