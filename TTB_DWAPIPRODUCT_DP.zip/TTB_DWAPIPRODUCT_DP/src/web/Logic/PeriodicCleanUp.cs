﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;
using TTB.Logging;

namespace TTB_DWAPIPRODUCT_DP.Logic
{
    public class PeriodicCleanUp : IHostedService, IDisposable
    {
        private int executionCount = 0;
        private readonly TTBLogger _logger;
        private readonly Service _service;
        private Timer _timer;

        public PeriodicCleanUp(TTBLogger logger, Service service)
        {
            this._logger = logger;
            this._service = service;
        }

        public Task StartAsync(CancellationToken stoppingToken)
        {
            var period = TimeSpan.FromHours(1);
            this._timer = new Timer(this.DoWork, null, TimeSpan.Zero, period);
            return Task.CompletedTask;
        }

        private void DoWork(object state)
        {
            var count = Interlocked.Increment(ref executionCount);
            this._service.PurgeExpired();
        }

        public Task StopAsync(CancellationToken stoppingToken)
        {
            _timer?.Change(Timeout.Infinite, 0);
            return Task.CompletedTask;
        }

        public void Dispose()
        {
            _timer?.Dispose();
        }
    }
}
