using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;
using System.Threading.Tasks;
using System.Data;
using System.IO;
using System.Net.Http;
using System.Web;
using Newtonsoft.Json;
using TTB.Logging;
using TTB_DWAPIPRODUCT_DP.Definitions;

namespace TTB_DWAPIPRODUCT_DP.Logic
{
    public class Service
    {
        public const string CONTENT_TYPE_JSON = "application/json";
        public const string INSTITUTION_NAME = "TTB";
        public const string ACCOUNT_TYPE = "DEPOSIT";
        public const string NOTIFY_STATUS_SUCCESS = "Success";
        public const string NOTIFY_STATUS_NO_DATA = "No Data";
        public const string NOTIFY_STATUS_FAILURE = "Failure";
        public const int DEFAULT_TIMEZONE_OFFSET = +7;
        public const int ENDING_DATE_RANGE = 2;
        public const bool SHOW_INVALID_PARAMETERS_DETAIL = true;
        private readonly TTBLogger logger;
        private readonly Setup setup;
        private readonly DataAccess access;
        private static HttpClient httpClient;  // singleton https://www.aspnetmonsters.com/2016/08/2016-08-27-httpclientwrong/

        private HttpClient GetHttpClient()
        {
            if (Service.httpClient == null)
            {
                var validateCert = setup.Options.CertificateValidation;
                if (validateCert ?? true)
                {
                    Service.httpClient = new HttpClient();
                }
                else
                {
                    var handler = new HttpClientHandler();
                    handler.ServerCertificateCustomValidationCallback += (message, cert, chain, errors) => true;
                    Service.httpClient = new HttpClient(handler);
                }
                Service.httpClient = new HttpClient();
            }
            return Service.httpClient;
        }

        public Service(TTBLogger logger, Setup setup, DataAccess access)
        {
            this.logger = logger;
            this.setup = setup;
            this.access = access;
        }
        public static string GetFileNameFromRequestId(string appId, string requestId)
        {
            return $"{appId}-{requestId}.json";
        }

        #pragma warning disable IDE1006
        public async Task dwh_as_statement(StatementRequest request, string downloadUriBase)
        {
            try
            {
                await this.ProcessResponseGenerationAndCallback(request, downloadUriBase);
            }
            catch (Exception e)
            {
                this.logger.TTBLogError(nameof(ProcessResponseGenerationAndCallback), null, request.request_uuid, null, e, request, null);
            }
        }
        #pragma warning restore IDE1006

        public static DateTime ParseDateTime(string s)
        {
            return DateTimeOffset.Parse(s, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind).DateTime;
        }
        public static string FormatIso8601WithoutMilliseconds(DateTimeOffset dto)
        {
            /* https://stackoverflow.com/a/36314187/77996 */
            string format = dto.Offset == TimeSpan.Zero
                ? "yyyy-MM-ddTHH:mm:ssZ"
                : "yyyy-MM-ddTHH:mm:sszzz";
            return dto.ToString(format, CultureInfo.InvariantCulture);
        }
        public static string FormatDateTime(DateTime? d)
        {
            if (! d.HasValue) return FormatString(null);
            var t = new DateTimeOffset(d.Value, TimeSpan.FromHours(DEFAULT_TIMEZONE_OFFSET));
            var s = FormatIso8601WithoutMilliseconds(t);
            return FormatString(s);
        }
        public static string FormatString(string s, string defaultValue = null)
        {
            return string.IsNullOrWhiteSpace(s) ? defaultValue : s.Trim();
        }
        public static string FormatString(string s, int maxLength)
        {
            return FormatStringTakeBeginning(s, maxLength);
        }
        public static string FormatStringTakeBeginning(string s, int maxLength)
        {
            var r = FormatString(s);
            if (r == null) return r;
            var start = 0;
            var length = Math.Min(r.Length, maxLength);
            return r.Substring(start, length);
        }
        public static string FormatStringTakeEnding(string s, int maxLength)
        {
            var r = FormatString(s);
            if (r == null) return r;
            var start = Math.Max(0, r.Length - maxLength);
            var length = Math.Min(r.Length, maxLength);
            return r.Substring(start, length);
        }
        public static string FormatStringTakeBeginning(string s, int maxLength, string defaultValue)
        {
            var r = FormatString(s, defaultValue);
            if (r == null) return r;
            var start = 0;
            var length = Math.Min(r.Length, maxLength);
            return r.Substring(start, length);
        }
        public static string FormatStringTakeEnding(string s, int maxLength, string defaultValue)
        {
            var r = FormatString(s, defaultValue);
            if (r == null) return r;
            var start = Math.Max(0, r.Length - maxLength);
            var length = Math.Min(r.Length, maxLength);
            return r.Substring(start, length);
        }
        public static decimal? FormatDecimal(decimal? d, decimal? defaultValue = null)
        {
            return d.HasValue ? d : defaultValue;
        }
        private static void BlankOutDependentColumns(Statement s)
        {
            if (! s.lastLedgerBalanceAmount.HasValue) s.lastLedgerBalanceCurrency = null;
            if (! s.lastAvailableBalanceAmount.HasValue) s.lastAvailableBalanceCurrency = null;
        }
        protected virtual StatementAcct GetStatementAcct(IDbConnection c, string custId, string accountId, DateTime? start, DateTime? end, string language)
        {
            return this.access.Get<StatementAcct>(c, custId, accountId, start, end, language);
        }
        protected StatementAcct GetStatementAcctWithFallbackValues(IDbConnection c, string custId, string accountId, DateTime? start, DateTime? end, string language)
        {
            var r = this.GetStatementAcct(c, custId, accountId, start, end, language);
            var needFallback =
                r == null ||
                !r.LAST_LEDGER_BALANCE_AMOUNT.HasValue ||
                !r.LAST_AVAILABLE_BALANCE_AMOUNT.HasValue ||
                !r.CREDIT_LIMIT.HasValue;
            if (needFallback)
            {
                var latest = this.GetStatementAcct(c, custId, accountId, null, null, language);
                if (latest != null)
                {
                    if (r == null) r = latest;
                    else
                    {
                        r.LAST_LEDGER_BALANCE_AMOUNT = r.LAST_LEDGER_BALANCE_AMOUNT ?? latest.LAST_LEDGER_BALANCE_AMOUNT;
                        r.LAST_AVAILABLE_BALANCE_AMOUNT = r.LAST_AVAILABLE_BALANCE_AMOUNT ?? latest.LAST_AVAILABLE_BALANCE_AMOUNT;
                        r.CREDIT_LIMIT = r.CREDIT_LIMIT ?? latest.CREDIT_LIMIT;
                    }
                }
            }
            return r;
        }
        protected StatementAcct GetStatementAcctOnEndingDates(IDbConnection c, string custId, string accountId, DateTime? start, DateTime? end, string language)
        {
            var endDate = end.Value.Date;
            var backDays = ENDING_DATE_RANGE - 1;
            var startDate = endDate.AddDays(-backDays);
            return this.GetStatementAcct(c, custId, accountId, startDate, endDate, language);
        }
        protected StatementAcct GetStatementAcctRecently(IDbConnection c, string custId, string accountId, DateTime? start, DateTime? end, string language)
        {
            var latest = this.GetStatementAcct(c, custId, accountId, null, null, language);
            if (latest != null)
            {
                var MinDateAllowed = DateTime.Today.Date.AddDays(-2);
                if (latest.ACCOUNT_STATUS == "OTHERS") 
                    latest = null;
                else if (latest.AS_OF_DATE.Value.Date < MinDateAllowed) 
                    throw new Exception($"Data T-3: ({FormatDateTime(latest.AS_OF_DATE)})");
            }
            return latest;
        }
        protected virtual IEnumerable<StatementTran> QueryStatementTran(IDbConnection c, string accountId, DateTime? start, DateTime? end)
        {
            return this.access.Query<StatementTran>(c, accountId, start, end);
        }
        protected void refineRequestDateRange(ref DateTime start, ref DateTime end)
        {
            var MIN_START = DateTime.Today.AddDays(-this.setup.Options.StatementRange.Value);
            var MAX_END = DateTime.Today.AddDays(1).AddMinutes(-1);
            if (start < MIN_START) start = MIN_START;
            if (end > MAX_END) end = MAX_END;
        }
        protected static void ComputeEffectiveDateRange(StatementRequest request, StatementAcct acct, out string effective_start_datetime, out string effective_end_datetime)
        {
            effective_start_datetime = request.start_datetime;
            effective_end_datetime = request.end_datetime;
            if (acct.ACCOUNT_OPEN_DATE.HasValue)
            {
                try
                {
                    if (acct.ACCOUNT_OPEN_DATE.Value > ParseDateTime(request.start_datetime))
                    {
                        effective_start_datetime = FormatDateTime(acct.ACCOUNT_OPEN_DATE);
                    }
                    if (acct.ACCOUNT_OPEN_DATE.Value > ParseDateTime(request.end_datetime))
                    {
                        effective_end_datetime = FormatDateTime(acct.ACCOUNT_OPEN_DATE);
                    }
                }
                catch { }
            }
        }
        public async Task<DownloadResponse> GenerateResponse(StatementRequest request)
        {
            var invalids = request.FindInvalids(this.setup.Options.MaximumAccountRequest, this.setup.Options.StatementRange);
            if (invalids.Any())
                throw new NotifyRequest.NotifyWithException()
                {
                    NotifyRequest = new NotifyRequest()
                    {
                        request_id = request.request_id,
                        download_url = "",
                        status = NOTIFY_STATUS_FAILURE,
                        status_detail = SHOW_INVALID_PARAMETERS_DETAIL
                            ? $"Invalid Input Parameter ({String.Join(", ", invalids)})"
                            : "Invalid Input Parameter",
                        accounts = request.accounts
                    }
                };
            var statements = new List<Statement>();
            if (request.accounts != null && request.accounts?.Length != 0)
            {
                var custId = request.rm_id;
                var start = ParseDateTime(request.start_datetime);
                var end = ParseDateTime(request.end_datetime);
                var lang = request.language;
                await this.access.UsingDb(async c =>
                {
                    foreach (var accountId in request.accounts)
                    {
                        var acct = this.GetStatementAcctRecently(c, custId, accountId, start, end, lang);
                        if (acct != null)
                        {
                            var entries = new List<Statement.Entry>();
                            foreach (var tran in this.QueryStatementTran(c, accountId, start, end))
                            {
                                entries.Add(new Statement.Entry()
                                {
                                    bookingDateTime                       = FormatDateTime(tran.BOOKING_DATE_TIME),
                                    valueDateTime                         = FormatDateTime(tran.VALUE_DATE_TIME),
                                    bankTransactionCode                   = FormatString(tran.BANK_TRAN_CODE),
                                    proprietaryBankTransactionCode        = FormatString(tran.TTB_BANK_TRAN_CODE),
                                    proprietaryBankTransactionDescription = FormatString(tran.TTB_BANK_TRANS_DESC),
                                    creditDebitIndicator                  = FormatString(tran.CREDIT_DEBIT_INDICATOR),
                                    amount                                = FormatDecimal(tran.AMOUNT),
                                    amountCurrency                        = FormatString(tran.AMOUNT_CURRENCY),
                                    balance                               = FormatDecimal(tran.BALANCE),
                                    balanceCurrency                       = FormatString(tran.BALANCE_CURRENCY)
                                });
                            }
                            const int MAX_STATEMENT_ID_LENGTH = 20;
                            var statementId = NewStatementId(request.request_id);
                            ComputeEffectiveDateRange(request, acct, out var effective_start_datetime, out var effective_end_datetime);
                            var s = new Statement()
                            {
                                creationDateTime             = FormatDateTime(acct.CREATION_DATE_TIME),
                                statementId                  = FormatString(statementId, MAX_STATEMENT_ID_LENGTH),
                                auxiliaryReferenceId         = FormatString(request.auxiliaryReferenceId),
                                institutionName              = FormatString(INSTITUTION_NAME),
                                accountId                    = FormatString(accountId),
                                ownerType                    = FormatString(acct.OWNER_TYPE),
                                accountType                  = FormatString(ACCOUNT_TYPE),
                                accountSubType               = FormatString(acct.ACCOUNT_SUB_TYPE),
                                accountStatus                = FormatString(acct.ACCOUNT_STATUS),
                                accountName                  = FormatString(acct.ACCOUNT_NAME),
                                lastLedgerBalanceAmount      = FormatDecimal(acct.LAST_LEDGER_BALANCE_AMOUNT),
                                lastLedgerBalanceCurrency    = FormatString(acct.LAST_LEDGER_BALANCE_CURR, ""),
                                lastAvailableBalanceAmount   = FormatDecimal(acct.LAST_AVAILABLE_BALANCE_AMOUNT),
                                lastAvailableBalanceCurrency = FormatString(acct.LAST_AVAILABLE_BALANCE_CURR),
                                startDateTime                = effective_start_datetime,
                                endDateTime                  = effective_end_datetime,
                                numberofTotalItems           = entries.Count,
                                creditLimit                  = FormatDecimal(acct.CREDIT_LIMIT),
                                statementEntries             = entries.ToArray()
                            };
                            BlankOutDependentColumns(s);
                            statements.Add(s);
                        }
                    }
                    await Task.CompletedTask;
                });
            }
            var response = new DownloadResponse() { AccountStatement = statements.ToArray() };
            return response;
        }


        private static Random random = new Random();

        public static string NewStatementId(string request_id)
        {
            const int TOTAL_LENGTH   = 20;
            const int PART_REQUEST   = 4;
            const int PART_THREAD    = 2;
            const int PART_RANDOM    = 5;
            const int PART_TIMESTAMP = TOTAL_LENGTH - PART_REQUEST - PART_THREAD - PART_RANDOM;
            string FixedLength(string s, int length)
            {
                return FormatStringTakeEnding(s, length, "").PadLeft(length, '0');
            }
            var partRequest = FixedLength(request_id, PART_REQUEST);
            var partThread = FixedLength(System.Threading.Thread.CurrentThread.ManagedThreadId.ToString(), PART_THREAD);
            var partRandom = FixedLength(random.Next(Convert.ToInt32(Math.Pow(16, PART_RANDOM)) - 1).ToString("X"), PART_RANDOM);
            var partTimestamp = FixedLength(DateTime.Now.ToBinary().ToString("X"), PART_TIMESTAMP);
            return $"{partRequest}{partThread}{partRandom}{partTimestamp}";
        }

        private void EnsureStatementDirectory()
        {
            if (! Directory.Exists(this.setup.StatementPath)) Directory.CreateDirectory(this.setup.StatementPath);
        }
        public async Task<string> GenerateResponseContent(StatementRequest request)
        {
            var r = await this.GenerateResponse(request);
            return this.setup.SerializeJsonObject(r);
        }
        public async Task<(DownloadResponse, string fname, string fullPath)> GenerateResponseToFile(StatementRequest request)
        {
            var generating = this.GenerateResponse(request);
            var fname = GetFileNameFromRequestId(request.app_id, request.request_id);
            var fullPath = Path.Combine(this.setup.StatementPath, fname);
            this.EnsureStatementDirectory();
            var response = await generating;
            var content = this.setup.SerializeJsonObject(response);
            Console.WriteLine(fullPath);
            File.WriteAllText(fullPath, content);
            return (response, fname, fullPath);
        }
        public async Task<DownloadResponse> GenerateResponseToDatabase(StatementRequest request)
        {
            var generating = this.GenerateResponse(request);
            var response = await generating;
            var content = this.setup.SerializeJsonObject(response);
            throw new NotImplementedException();
        }
        public virtual async Task<DownloadResponse> GenerateResponseToStorage(StatementRequest request)
        {
            var (response, fname, fullPath) = await this.GenerateResponseToFile(request);
            return response;
        }
        public async Task<NotifyRequest> GenerateResponseAndReturnNotifyRequest(StatementRequest request, string downloadUriBase)
        {
            NotifyRequest notifyRequest = null;
            try
            {
                var accounts = request.accounts ?? new string[0];
                var response = await this.GenerateResponseToStorage(request);
                var b = new UriBuilder(downloadUriBase);
                var query = HttpUtility.ParseQueryString(b.Query);
                query[nameof(request.request_id)] = request.request_id;
                if (!string.IsNullOrWhiteSpace(request.app_id)) query[nameof(request.app_id)] = request.app_id;
                if (!string.IsNullOrWhiteSpace(request.request_uuid)) query[nameof(request.request_uuid)] = request.request_uuid;
                query[nameof(request.rm_id)] = request.rm_id;
                query[nameof(request.auxiliaryReferenceId)] = request.auxiliaryReferenceId;
                b.Query = query.ToString();
                var downloadUrl = b.ToString();
                string status;
                string statusDetail;
                if (response.AccountStatement?.Length == 0)
                {
                    status = NOTIFY_STATUS_NO_DATA;
                    statusDetail = "";
                    downloadUrl = "";
                }
                else
                {
                    status = NOTIFY_STATUS_SUCCESS;
                    statusDetail = $"{response.AccountStatement.Length} records found";
                    accounts = response.AccountStatement.Select(a => a.accountId).ToArray();
                }
                notifyRequest = new NotifyRequest()
                {
                    request_id = request.request_id,
                    auxiliaryReferenceId = request.auxiliaryReferenceId,
                    download_url = downloadUrl,
                    status = status,
                    status_detail = statusDetail,
                    accounts = accounts,
                    request_uuid = request.request_uuid
                };
            }
            catch (NotifyRequest.NotifyWithException e)
            {
                this.logger.TTBLogError(nameof(GenerateResponseAndReturnNotifyRequest), null, request.request_uuid, null, e, request, null);
                notifyRequest = e.NotifyRequest;
            }
            catch (Exception e)
            {
                this.logger.TTBLogError(nameof(GenerateResponseAndReturnNotifyRequest), null, request.request_uuid, null, e, request, null);
                notifyRequest = new NotifyRequest()
                {
                    request_id = request.request_id,
                    download_url = "",
                    status = NOTIFY_STATUS_FAILURE,
                    status_detail = e.Message,
                    accounts = request.accounts
                };
            }
            return notifyRequest;
        }
        public async Task ProcessResponseGenerationAndCallback(StatementRequest request, string downloadUriBase)
        {
            var notifyRequest = await this.GenerateResponseAndReturnNotifyRequest(request, downloadUriBase);
            await this.Notify(request.callback_url, notifyRequest);
        }
        public async Task<string> DownloadStatementContent(DownloadRequest request)
        {
            var fname = GetFileNameFromRequestId(request.app_id, request.request_id);
            var fullPath = Path.Combine(this.setup.StatementPath, fname);
            return await File.ReadAllTextAsync(fullPath);
        }
        public async Task Notify(string url, NotifyRequest req)
        {
            var func = $"{nameof(Service)}.{nameof(Notify)}";
            string session = null;
            var s = JsonConvert.SerializeObject(req);
            var content = new StringContent(s, Encoding.UTF8, CONTENT_TYPE_JSON);
            await this.logger.TTBLogOutbound(func, session, req.request_uuid, null, s, url, async change =>
            {
                using (var resp = await this.GetHttpClient().PostAsync(url, content))
                {
                    try
                    {
                        _ = await resp.Content.ReadAsStringAsync();
                    }
                    finally
                    {
                        change((int)resp.StatusCode, null);
                    }
                }
                return true;
            });
        }
        public async Task<string> Test()
        {
            return await this.access.FromDb(async (c) =>
            {
                return await Task.FromResult("It works.");
            });
        }
        public async Task<string> Encrypt(string value)
        {
            return await Task.FromResult(AESEncryption.Encrypt(value, this.setup.Options.AesPassword, this.setup.Options.AesSalt));
        }
        public async Task<string> Decrypt(string value)
        {
            return await Task.FromResult(AESEncryption.Decrypt(value, this.setup.Options.AesPassword, this.setup.Options.AesSalt));
        }
        private IEnumerable<string> ExpiredFiles(string dir, int retention)
        {
            var now = DateTime.Now;
            if ((!string.IsNullOrWhiteSpace(dir)) && Directory.Exists(dir))
            {
                foreach (var fname in Directory.EnumerateFiles(dir))
                {
                    var fullname = Path.Combine(dir, fname);
                    int age = 0;
                    try
                    {
                        age = Convert.ToInt32((now - File.GetLastWriteTime(fullname)).TotalDays);
                    }
                    catch { }
                    if (age > retention) yield return fullname;
                }
            }
        }
        private IEnumerable<string> AllExpiredFiles()
        {
            var now = DateTime.Now;
            if (this.setup.Options.StatementFileRetention.HasValue)
            {
                foreach (var f in ExpiredFiles(this.setup.StatementPath, this.setup.Options.StatementFileRetention.Value))
                {
                    if (!f.ToLower().EndsWith(".json")) continue;
                    yield return f;
                }
            }
            if (this.setup.Options.LogFileRetention.HasValue && ! string.IsNullOrWhiteSpace(this.setup.LogPath))
            {
                foreach (var f in ExpiredFiles(this.setup.LogPath, this.setup.Options.LogFileRetention.Value))
                {
                    if ((!f.ToLower().EndsWith(".txt")) && (!f.ToLower().EndsWith(".log"))) continue;
                    yield return f;
                }
            }
        }
        public void PurgeExpired()
        {
            foreach (var fullname in this.AllExpiredFiles())
            {
                try
                {
                    File.Delete(fullname);
                }
                catch { }
            }
        }
    }
}
