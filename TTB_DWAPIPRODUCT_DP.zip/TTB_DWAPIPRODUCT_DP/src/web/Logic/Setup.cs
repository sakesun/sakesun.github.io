﻿using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.IO;
using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace TTB_DWAPIPRODUCT_DP.Logic
{
    public class Setup
    {
        const string DEFAULT_AES_SALT = "TTB_DWAPIPRODUCT_DP";
        const string DEFAULT_AES_PASSWORD = "TTB_DWAPIPRODUCT_DP";
        const int DEFAULT_MAXIMUM_ACCOUNT_REQUEST = 5;
        const int DEFAULT_STATEMENT_FILE_RETENTION = 7;
        const int DEFAULT_LOG_FILE_RETENTION = 30;
        const int DEFAULT_STATEMENT_RANGE = 180;
        const string DEFAULT_STATEMENT_FILE_PATH = "BOTSTMT";
        private readonly JsonSerializerSettings serializerSettings;

        public Setup(IConfiguration cfg, IHostingEnvironment env)
        {
            this.Options = LoadConfigurationOptions(cfg, env);
            BuildEnvironmentDependents(env, this.Options,
                out bool checkField,
                out string statementPath,
                out string logPath,
                out JsonSerializerSettings serializerSettings);
            this.CheckField = checkField;
            this.StatementPath = statementPath;
            this.LogPath = logPath;
            this.serializerSettings = serializerSettings;
        }

        public virtual SetupOptions Options { get; }
        public virtual bool CheckField { get; }
        public virtual string StatementPath { get; }
        public virtual string LogPath { get; }
        public virtual string SerializeJsonObject(object o)
        {
            return JsonConvert.SerializeObject(o, this.serializerSettings);
        }

        private static SetupOptions LoadConfigurationOptions(IConfiguration cfg, IHostingEnvironment env)
        {
            var o = new SetupOptions();
            if (cfg != null) cfg.Bind(o);
            if (o.AesSalt == null) o.AesSalt = DEFAULT_AES_SALT;
            if (o.AesPassword == null) o.AesPassword = DEFAULT_AES_PASSWORD;
            if (string.IsNullOrWhiteSpace(o.BaseURL)) o.BaseURL = "";
            if ((!o.BaseURL.Contains(":")) && (!o.BaseURL.StartsWith("/"))) o.BaseURL = "/" + o.BaseURL;
            if (!o.BaseURL.EndsWith("/")) o.BaseURL = o.BaseURL + "/";
            if (string.IsNullOrWhiteSpace(o.DWHConnection)) o.DWHConnection = "";
            if (! o.MaximumAccountRequest.HasValue) o.MaximumAccountRequest = DEFAULT_MAXIMUM_ACCOUNT_REQUEST;
            if (!o.StatementRange.HasValue) o.StatementRange = DEFAULT_STATEMENT_RANGE;
            if (! o.StatementFileRetention.HasValue) o.StatementFileRetention = DEFAULT_STATEMENT_FILE_RETENTION;
            if (string.IsNullOrWhiteSpace(o.StatementFilePath)) o.StatementFilePath = DEFAULT_STATEMENT_FILE_PATH;
            if (!o.LogFileRetention.HasValue) o.LogFileRetention = DEFAULT_LOG_FILE_RETENTION;
            return o;
        }

        private static IEnumerable<string> FindLogDirs(IHostingEnvironment env, SetupOptions opt)
        {
            string log4netConfig;
            if (env != null)
            {
                log4netConfig = env.ContentRootFileProvider.GetFileInfo("log4net.config").PhysicalPath;
                var doc = new XmlDocument();
                doc.Load(log4netConfig);
                var log4net = doc.ChildNodes.OfType<XmlElement>().First(el => el.Name == "log4net");
                if (log4net != null)
                {
                    var appenders = log4net.ChildNodes.OfType<XmlElement>().Where(el => el.Name == "appender");
                    foreach (var a in appenders)
                    {
                        foreach (var f in a.OfType<XmlElement>().Where(el => el.Name == "file"))
                        {
                            if (f.HasAttribute("value"))
                            {
                                var value = f.GetAttribute("value");
                                if (!string.IsNullOrWhiteSpace(value)) yield return value;
                            }
                        }
                    }
                }
            }
        }

        private static string ResolveLogFilePath(IHostingEnvironment env, SetupOptions opt)
        {
            return FindLogDirs(env, opt).FirstOrDefault();
        }

        private static void BuildEnvironmentDependents(
            IHostingEnvironment env, SetupOptions options, 
            out bool checkField, out string statementPath, out string logPath, out JsonSerializerSettings serializerSettings)
        {
            checkField = true;
            statementPath = DEFAULT_STATEMENT_FILE_PATH;
            logPath = null;
            serializerSettings = new JsonSerializerSettings();
            if (env != null)
            {
                checkField = env.IsDevelopment();
                statementPath = BuildFullPath(env, options.StatementFilePath);
                logPath = BuildLogPath(ResolveLogFilePath(env, options));
                serializerSettings = new JsonSerializerSettings();
                Startup.ConfigureJsonSerializerSettings(serializerSettings, env.IsDevelopment());
            }
        }

        private static string BuildFullPath(IHostingEnvironment env, string p)
        {
            p = p.Replace("/", "\\");
            var absolute = p.StartsWith("\\") || p.Contains(":");
            if (absolute) return p;
            return env.ContentRootFileProvider.GetFileInfo(p).PhysicalPath;
        }

        private static string BuildLogPath(string p)
        {
            if (string.IsNullOrEmpty(p)) return null;
            p = p.Replace("/", "\\");
            var absolute = p.StartsWith("\\") || p.Contains(":");
            if (absolute) return p;
            return Path.Combine(Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location), p);
        }

        public class SetupOptions
        {
            [JsonPropertyName("AesSalt")]
            public string AesSalt { get; set; }
            [JsonPropertyName("AesPassword")]
            public string AesPassword { get; set; }
            [JsonPropertyName("CertificateValidation")]
            public bool? CertificateValidation { get; set; }
            [JsonPropertyName("BaseURL")]
            public string BaseURL { get; set; }
            [JsonPropertyName("DWHConnection")]
            public string DWHConnection { get; set; }
            [JsonPropertyName("StatementFilePath")]
            public string StatementFilePath { get; set; }
            [JsonPropertyName("StatementFileRetention")]
            public int? StatementFileRetention { get; set; }
            [JsonPropertyName("StatementRange")]
            public int? StatementRange { get; set; }
            [JsonPropertyName("MaximumAccountRequest")]
            public int? MaximumAccountRequest { get; set; }
            [JsonPropertyName("LogFileRetention")]
            public int? LogFileRetention { get; set; }
        }
    }
}
