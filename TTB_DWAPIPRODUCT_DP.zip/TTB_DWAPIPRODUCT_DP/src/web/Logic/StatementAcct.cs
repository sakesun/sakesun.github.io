using System;
using System.Linq;
using System.Data;
using System.Collections.Generic;

namespace TTB_DWAPIPRODUCT_DP.Logic
{
    public class StatementAcct
    {
        /* Fields */
        public DateTime? CREATION_DATE_TIME { get; set; }
        public DateTime? AS_OF_DATE { get; set; }
        public string INSTITUTION_NAME { get; set; }
        public string CUST_ID { get; set; }
        public string ACCOUNT_ID { get; set; }
        public string OWNER_TYPE { get; set; }
        public string ACCOUNT_TYPE { get; set; }
        public string ACCOUNT_SUB_TYPE { get; set; }
        public string ACCOUNT_STATUS { get; set; }
        public string ACCOUNT_NAME { get; set; }
        public decimal? LAST_LEDGER_BALANCE_AMOUNT { get; set; }
        public string LAST_LEDGER_BALANCE_CURR { get; set; }
        public decimal? LAST_AVAILABLE_BALANCE_AMOUNT { get; set; }
        public string LAST_AVAILABLE_BALANCE_CURR { get; set; }
        public decimal? CREDIT_LIMIT { get; set; }
        public DateTime? ACCOUNT_OPEN_DATE { get; set; }
    }

    public static class StatementAcctExtension
    {
        public enum Params { V_CUST_ID, V_ACCOUNT_ID, V_START_DATE, V_END_DATE, V_LANGUAGE }

        public static StatementAcct Get<T>(this DataAccess d, IDbConnection c, string custId, string accountId, DateTime? start, DateTime? end, string language)
            where T : StatementAcct
        {
            return d.Query<StatementAcct>(c, custId, accountId, start, end, language).FirstOrDefault();
        }

        public static IEnumerable<StatementAcct> Query<T>(this DataAccess d, IDbConnection c, string custId, string accountId, DateTime? start, DateTime? end, string language)
            where T: StatementAcct
        {
            var withDateRange = start.HasValue || end.HasValue;
            using (var cmd = c.CreateCommand())
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = GetSql(withDateRange);
                d.AddStringParameter(cmd, nameof(Params.V_CUST_ID), custId);
                d.AddStringParameter(cmd, nameof(Params.V_ACCOUNT_ID), accountId);
                if (withDateRange)
                {
                    d.AddDateParameter(cmd, nameof(Params.V_START_DATE), start);
                    d.AddDateParameter(cmd, nameof(Params.V_END_DATE), end);
                }
                d.AddStringParameter(cmd, nameof(Params.V_LANGUAGE), language);
                using (var r = cmd.ExecuteReader())
                {
                    bool read = false;
                    while (r.Read())
                    {
                        read = true;
                        int i = 0;
                        var a = new StatementAcct();
                        a.CREATION_DATE_TIME            = d.GetDateField   (r, i++, nameof(a.CREATION_DATE_TIME));
                        a.AS_OF_DATE                    = d.GetDateField   (r, i++, nameof(a.AS_OF_DATE));
                        a.INSTITUTION_NAME              = d.GetStringField (r, i++, nameof(a.INSTITUTION_NAME));
                        a.CUST_ID                       = d.GetStringField (r, i++, nameof(a.CUST_ID));
                        a.ACCOUNT_ID                    = d.GetStringField (r, i++, nameof(a.ACCOUNT_ID));
                        a.OWNER_TYPE                    = d.GetStringField (r, i++, nameof(a.OWNER_TYPE));
                        a.ACCOUNT_TYPE                  = d.GetStringField (r, i++, nameof(a.ACCOUNT_TYPE));
                        a.ACCOUNT_SUB_TYPE              = d.GetStringField (r, i++, nameof(a.ACCOUNT_SUB_TYPE));
                        a.ACCOUNT_STATUS                = d.GetStringField (r, i++, nameof(a.ACCOUNT_STATUS));
                        a.ACCOUNT_NAME                  = d.GetStringField (r, i++, nameof(a.ACCOUNT_NAME));
                        a.LAST_LEDGER_BALANCE_AMOUNT    = d.GetDecimalField(r, i++, nameof(a.LAST_LEDGER_BALANCE_AMOUNT));
                        a.LAST_LEDGER_BALANCE_CURR      = d.GetStringField (r, i++, nameof(a.LAST_LEDGER_BALANCE_CURR));
                        a.LAST_AVAILABLE_BALANCE_AMOUNT = d.GetDecimalField(r, i++, nameof(a.LAST_AVAILABLE_BALANCE_AMOUNT));
                        a.LAST_AVAILABLE_BALANCE_CURR   = d.GetStringField (r, i++, nameof(a.LAST_AVAILABLE_BALANCE_CURR));
                        a.CREDIT_LIMIT                  = d.GetDecimalField(r, i++, nameof(a.CREDIT_LIMIT));
                        a.ACCOUNT_OPEN_DATE             = d.GetDateField   (r, i++, nameof(a.ACCOUNT_OPEN_DATE));
                        yield return a;
                    }
                    if ((!read) && d.CheckField)
                    {
                        int i = 0;
                        StatementAcct a;
                        d.CheckDateField   (r, i++, nameof(a.CREATION_DATE_TIME));
                        d.CheckDateField   (r, i++, nameof(a.AS_OF_DATE));
                        d.CheckStringField (r, i++, nameof(a.INSTITUTION_NAME));
                        d.CheckStringField (r, i++, nameof(a.CUST_ID));
                        d.CheckStringField (r, i++, nameof(a.ACCOUNT_ID));
                        d.CheckStringField (r, i++, nameof(a.OWNER_TYPE));
                        d.CheckStringField (r, i++, nameof(a.ACCOUNT_TYPE));
                        d.CheckStringField (r, i++, nameof(a.ACCOUNT_SUB_TYPE));
                        d.CheckStringField (r, i++, nameof(a.ACCOUNT_STATUS));
                        d.CheckStringField (r, i++, nameof(a.ACCOUNT_NAME));
                        d.CheckDecimalField(r, i++, nameof(a.LAST_LEDGER_BALANCE_AMOUNT));
                        d.CheckStringField (r, i++, nameof(a.LAST_LEDGER_BALANCE_CURR));
                        d.CheckDecimalField(r, i++, nameof(a.LAST_AVAILABLE_BALANCE_AMOUNT));
                        d.CheckStringField (r, i++, nameof(a.LAST_AVAILABLE_BALANCE_CURR));
                        d.CheckDecimalField(r, i++, nameof(a.CREDIT_LIMIT));
                        d.CheckDateField   (r, i++, nameof(a.ACCOUNT_OPEN_DATE));
                    }
                }
            }
        }

        public static string GetSql(bool withDateRange = true)
        {
            var and_ByDateRange = withDateRange ? $"AND AS_OF_DATE BETWEEN :{nameof(Params.V_START_DATE)} AND :{nameof(Params.V_END_DATE)}" : "";
            StatementAcct a;
            return $@"
SELECT {nameof(a.CREATION_DATE_TIME)}
     , {nameof(a.AS_OF_DATE)}
     , {nameof(a.INSTITUTION_NAME)}
     , {nameof(a.CUST_ID)}
     , {nameof(a.ACCOUNT_ID)}
     , {nameof(a.OWNER_TYPE)}
     , {nameof(a.ACCOUNT_TYPE)}
     , {nameof(a.ACCOUNT_SUB_TYPE)}
     , {nameof(a.ACCOUNT_STATUS)}
     , ( CASE :{nameof(Params.V_LANGUAGE)}
         WHEN 'TH' THEN ACCOUNT_NAME_TH
                   ELSE ACCOUNT_NAME_EN
         END )  {nameof(a.ACCOUNT_NAME)}
     , {nameof(a.LAST_LEDGER_BALANCE_AMOUNT)}
     , {nameof(a.LAST_LEDGER_BALANCE_CURR)}
     , {nameof(a.LAST_AVAILABLE_BALANCE_AMOUNT)}
     , {nameof(a.LAST_AVAILABLE_BALANCE_CURR)}
     , {nameof(a.CREDIT_LIMIT)}
     , {nameof(a.ACCOUNT_OPEN_DATE)}
  FROM TMBACS.VW_DP_STMT_ACCT
 WHERE CUST_ID = :{nameof(Params.V_CUST_ID)}
   AND ACCOUNT_ID = :{nameof(Params.V_ACCOUNT_ID)}
   {and_ByDateRange}
ORDER BY AS_OF_DATE DESC
FETCH FIRST 1 ROWS ONLY
";
        }

        public static string GetViewSql()
        {
            StatementAcct a;
            return $@"
CREATE OR REPLACE VIEW TMBACS.VW_DP_STMT_ACCT as
SELECT SYSDATE                                               {nameof(a.CREATION_DATE_TIME)}
     , DP_ACT.AS_OF_DATE                                     {nameof(a.AS_OF_DATE)}
     , 'TTB'                                                 {nameof(a.INSTITUTION_NAME)}
     , DP_ACT.TMB_CUST_ID                                    {nameof(a.CUST_ID)}
     , DP_ACT.TMB_ACCOUNT_ID                                 {nameof(a.ACCOUNT_ID)}
     , DECODE(CUST.CUST_TO_REL_CD, 'IND', 'INDIVIDUAL')      {nameof(a.OWNER_TYPE)}
     , 'DEPOSIT'                                             {nameof(a.ACCOUNT_TYPE)}
     , ( CASE WHEN DP_ACT.DATA_SOURCE = '34' THEN 'CURRENT'
              WHEN DP_ACT.DATA_SOURCE = '35' THEN 'SAVINGS'
              END )                                          {nameof(a.ACCOUNT_SUB_TYPE)}
     , NVL( CASE
              --CURRENT
              WHEN (DP_ACT.DATA_SOURCE = '34' AND DP_ACT.TMB_ACCOUNT_STATUS_CD = 0) THEN 'NORMAL'
              WHEN (DP_ACT.DATA_SOURCE = '34' AND DP_ACT.TMB_ACCOUNT_STATUS_CD = 6) THEN 'DORMANT'
              WHEN (DP_ACT.DATA_SOURCE = '34' AND DP_ACT.TMB_ACCOUNT_STATUS_CD = 7) THEN 'INACTIVE'
              --SAVINGS
              WHEN (DP_ACT.DATA_SOURCE = '35' AND DP_ACT.TMB_ACCOUNT_STATUS_CD = 0) THEN 'NORMAL'
              WHEN (DP_ACT.DATA_SOURCE = '35' AND DP_ACT.TMB_ACCOUNT_STATUS_CD = 2) THEN 'DORMANT'
              WHEN (DP_ACT.DATA_SOURCE = '35' AND DP_ACT.TMB_ACCOUNT_STATUS_CD = 1) THEN 'INACTIVE'
              END, 'OTHERS' )                                {nameof(a.ACCOUNT_STATUS)}
     , ACCOUNT_SHORT_NAME                                    ACCOUNT_NAME_EN
     , ACCT_NAME.ACCOUNT_NAME1                               ACCOUNT_NAME_TH
     , ( CASE
           --CURRENT
           WHEN DP_ACT.DATA_SOURCE = '34' THEN NVL(DP_ACT.TMB_CUR_BOOK_BAL, 0) + NVL(DP_ACT.TMB_OD_BAL, 0)
           --SAVINGS
           WHEN DP_ACT.DATA_SOURCE = '35' THEN NVL(DP_ACT.TMB_CUR_BOOK_BAL, 0)
           END )                                             {nameof(a.LAST_LEDGER_BALANCE_AMOUNT)}
     , DP_ACT.ISO_CURRENCY_CD                                {nameof(a.LAST_LEDGER_BALANCE_CURR)}
     , DP_ACT.AVAL_BAL                                       {nameof(a.LAST_AVAILABLE_BALANCE_AMOUNT)}
     , DP_ACT.ISO_CURRENCY_CD                                {nameof(a.LAST_AVAILABLE_BALANCE_CURR)}
     , NVL(DP_ACT.COMMITMENT_BAL,0)                          {nameof(a.CREDIT_LIMIT)}
     , DP_ACT.ACCOUNT_OPEN_DATE                              {nameof(a.ACCOUNT_OPEN_DATE)}
  FROM ADMINTMB.TMB_DP_DAILY_ACCT DP_ACT
  LEFT JOIN ADMINTMB.TMB_COMM_CUST_ACCOUNT CUST
    ON DP_ACT.TMB_ACCOUNT_ID = CUST.ACCT_NO
   AND DP_ACT.TMB_CUST_ID = CUST.CUST_ID
   AND CUST.CUST_FROM_REL_CD = 'PRI'
   AND CUST.DATA_SOURCE = 'RM'
   AND CUST.APPL_CD IN ('50', '60')
  LEFT JOIN ADMINTMB.TMB_ACCOUNT_NAME ACCT_NAME
    ON DP_ACT.TMB_ACCOUNT_ID = ACCT_NAME.TMB_ACCOUNT_NO
   AND DP_ACT.DATA_SOURCE = ACCT_NAME.DATA_SOURCE
 WHERE CUST.CUST_TO_REL_CD = 'IND' --INDIVIDUAL
   AND DP_ACT.DATA_SOURCE IN
   (
     '34', --CURRENT
     '35'  --SAVINGS
   )
";
        }
    }    
}
