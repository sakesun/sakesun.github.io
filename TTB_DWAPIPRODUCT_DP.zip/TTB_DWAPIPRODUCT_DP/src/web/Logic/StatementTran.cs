using System;
using System.Data;
using System.Collections.Generic;

namespace TTB_DWAPIPRODUCT_DP.Logic
{
    public class StatementTran
    {
        /* Fields */
        public DateTime? BOOKING_DATE_TIME { get; set; }
        public DateTime? VALUE_DATE_TIME { get; set; }
        public string BANK_TRAN_CODE { get; set; }
        public string TTB_BANK_TRAN_CODE { get; set; }
        public string TTB_BANK_TRANS_DESC { get; set; }
        public string CREDIT_DEBIT_INDICATOR { get; set; }
        public decimal? AMOUNT { get; set; }
        public string AMOUNT_CURRENCY { get; set; }
        public decimal? BALANCE { get; set; }
        public string BALANCE_CURRENCY { get; set; }
    }
    public static class StatementTranExtension
    {
        public enum Params { V_ACCOUNT_ID, V_START_DATE, V_END_DATE }

        public static IEnumerable<StatementTran> Query<T>(this DataAccess d, IDbConnection c, string accountId, DateTime? start, DateTime? end)
            where T: StatementTran
        {
            using (var cmd = c.CreateCommand())
            {
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = GetSql();
                d.AddStringParameter(cmd, nameof(Params.V_ACCOUNT_ID), accountId);
                d.AddDateParameter(cmd, nameof(Params.V_START_DATE), start);
                d.AddDateParameter(cmd, nameof(Params.V_END_DATE), end);
                using (var r = cmd.ExecuteReader())
                {
                    bool read = false;
                    while (r.Read())
                    {
                        read = true;
                        int i = 0;
                        var t = new StatementTran();
                        t.BOOKING_DATE_TIME = d.GetDateField(r, i++, nameof(t.BOOKING_DATE_TIME));
                        t.VALUE_DATE_TIME = d.GetDateField(r, i++, nameof(t.VALUE_DATE_TIME));
                        t.BANK_TRAN_CODE = d.GetStringField(r, i++, nameof(t.BANK_TRAN_CODE));
                        t.TTB_BANK_TRAN_CODE = d.GetStringField(r, i++, nameof(t.TTB_BANK_TRAN_CODE));
                        t.TTB_BANK_TRANS_DESC = d.GetStringField(r, i++, nameof(t.TTB_BANK_TRANS_DESC));
                        t.CREDIT_DEBIT_INDICATOR = d.GetStringField(r, i++, nameof(t.CREDIT_DEBIT_INDICATOR));
                        t.AMOUNT = d.GetDecimalField(r, i++, nameof(t.AMOUNT));
                        t.AMOUNT_CURRENCY = d.GetStringField(r, i++, nameof(t.AMOUNT_CURRENCY));
                        t.BALANCE = d.GetDecimalField(r, i++, nameof(t.BALANCE));
                        t.BALANCE_CURRENCY = d.GetStringField(r, i++, nameof(t.BALANCE_CURRENCY));
                        yield return t;
                    }
                    if ((!read) && d.CheckField)
                    {
                        int i = 0;
                        StatementTran t;
                        d.CheckDateField(r, i++, nameof(t.BOOKING_DATE_TIME));
                        d.CheckDateField(r, i++, nameof(t.VALUE_DATE_TIME));
                        d.CheckStringField(r, i++, nameof(t.BANK_TRAN_CODE));
                        d.CheckStringField(r, i++, nameof(t.TTB_BANK_TRAN_CODE));
                        d.CheckStringField(r, i++, nameof(t.TTB_BANK_TRANS_DESC));
                        d.CheckStringField(r, i++, nameof(t.CREDIT_DEBIT_INDICATOR));
                        d.CheckDecimalField(r, i++, nameof(t.AMOUNT));
                        d.CheckStringField(r, i++, nameof(t.AMOUNT_CURRENCY));
                        d.CheckDecimalField(r, i++, nameof(t.BALANCE));
                        d.CheckStringField(r, i++, nameof(t.BALANCE_CURRENCY));
                    }
                }
            }
        }

        public static string GetSql()
        {
            StatementTran t;
            return $@"
SELECT {nameof(t.BOOKING_DATE_TIME)}
     , {nameof(t.VALUE_DATE_TIME)}
     , {nameof(t.BANK_TRAN_CODE)}
     , {nameof(t.TTB_BANK_TRAN_CODE)}
     , {nameof(t.TTB_BANK_TRANS_DESC)}
     , {nameof(t.CREDIT_DEBIT_INDICATOR)}
     , {nameof(t.AMOUNT)}
     , {nameof(t.AMOUNT_CURRENCY)}
     , {nameof(t.BALANCE)}
     , {nameof(t.BALANCE_CURRENCY)}
  FROM TMBACS.VW_DP_STMT_TRAN
 WHERE {nameof(t.BOOKING_DATE_TIME)} BETWEEN :{nameof(Params.V_START_DATE)} AND :{nameof(Params.V_END_DATE)}
   AND ACCOUNT_NO IN (:{nameof(Params.V_ACCOUNT_ID)}, '0000' || :{nameof(Params.V_ACCOUNT_ID)})
 ORDER BY TRAN_DATE, TRAN_TIME, TRAN_SEQ
";
        }

        public static string GetViewSql()
        {
            StatementTran t;
            return $@"
CREATE OR REPLACE VIEW TMBACS.VW_DP_STMT_TRAN as
SELECT TXN.TRAN_DATE                    TRAN_DATE
     , TXN.TRAN_TIME                    TRAN_TIME
     , TXN.TRAN_SEQ                     TRAN_SEQ
     , TXN.ACCOUNT_NO                   ACCOUNT_NO
     , TO_DATE(TO_CHAR(TXN.TRAN_DATE, 'YYYY-MM-DD') || ' ' || TXN.TRAN_TIME, 'YYYY-MM-DD HH24MISS')
                                        {nameof(t.BOOKING_DATE_TIME)}
     , TRAN_EFF_DATE                    {nameof(t.VALUE_DATE_TIME)}
     , (CASE WHEN TRIM(TRAN_CODE)='01' AND TRAN_SYMB IS NULL THEN 'DB' ELSE TRAN_SYMB END)  
                                        {nameof(t.BANK_TRAN_CODE)}
     , (CASE WHEN TRIM(TRAN_CODE)='01' AND TRAN_SYMB IS NULL THEN 'DB' ELSE TRAN_SYMB END)  
                                        {nameof(t.TTB_BANK_TRAN_CODE)}
     , TRAN_CODE_DESC                   {nameof(t.TTB_BANK_TRANS_DESC)}
     , ( CASE
           --CURRENT
           WHEN (TXN.ACCOUNT_TYPE = 'CA' AND TXN.TRAN_TYPE IN ('1', '2')) THEN 'CRDT'
           WHEN (TXN.ACCOUNT_TYPE = 'CA' AND TXN.TRAN_TYPE IN ('3', '4')) THEN 'DBIT'
           --SAVINGS
           WHEN (TXN.ACCOUNT_TYPE = 'SA' AND TXN.TRAN_TYPE = '1') THEN 'CRDT'
           WHEN (TXN.ACCOUNT_TYPE = 'SA' AND TXN.TRAN_TYPE = '2') THEN 'DBIT'
           END )                        {nameof(t.CREDIT_DEBIT_INDICATOR)}
     , NVL(TXN.TRAN_AMOUNT, 0)          {nameof(t.AMOUNT)}
     , CURR_MAP.CODE_DESC_EN            {nameof(t.AMOUNT_CURRENCY)}
     , ( CASE
           WHEN TXN.CURR_BAL_SIGN = '-' THEN -NVL(TXN.CURRENT_BAL, 0)
           ELSE NVL(TXN.CURRENT_BAL, 0)
           END )                        {nameof(t.BALANCE)}
     , CURR_MAP.CODE_DESC_EN            {nameof(t.BALANCE_CURRENCY)}
  FROM TMBACS.ACS_DP_STMT_TRAN TXN
  LEFT JOIN TMBACS.ACS_DP_CUR_CODE_MAP CURR_MAP
         ON CURR_MAP.CODE_TYPE='CURR'
        AND LPAD(CURR_MAP.CODE, 4, '0') = TXN.CURRENCY_CODE
";
        }
    }
}
