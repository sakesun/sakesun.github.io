﻿using System.Net;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;

namespace TTB_DWAPIPRODUCT_DP
{
    public class Program
    {
        static void AllowSecurityProtocols()
        {
            ServicePointManager.SecurityProtocol =
                SecurityProtocolType.SystemDefault |
                SecurityProtocolType.Tls12 |
                SecurityProtocolType.Tls11 |
                SecurityProtocolType.Tls;
        }
        public static void Main(string[] args)
        {
            AllowSecurityProtocols();
            BuildWebHost(args).Run();
        }

        public static IWebHost BuildWebHost(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseStartup<Startup>()
                .Build();
    }
}
