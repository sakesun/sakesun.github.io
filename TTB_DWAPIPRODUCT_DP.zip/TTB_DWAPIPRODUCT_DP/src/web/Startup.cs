﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.OpenApi.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using DalSoft.Hosting.BackgroundQueue.DependencyInjection;
using TTB.Logging;

namespace TTB_DWAPIPRODUCT_DP
{
    public class Startup
    {
        public Startup(IConfiguration configuration, IHostingEnvironment hostEnv)
        {
            this.Configuration = configuration;
            this.HostingEnvironment = hostEnv;
        }

        public IConfiguration Configuration { get; }
        public IHostingEnvironment HostingEnvironment { get; }

        public static void DoNotModifyJsonPropertyName(JsonSerializerSettings settings)
        {
            settings.ContractResolver = new DefaultContractResolver();
        }

        public static void FormatJsonOutput(JsonSerializerSettings settings, bool prettyPrint)
        {
            settings.Formatting = prettyPrint ? Formatting.Indented : Formatting.None;
        }

        public static void ConfigureJsonSerializerSettings(JsonSerializerSettings settings, bool isDev)
        {
            settings.NullValueHandling = NullValueHandling.Include;
            FormatJsonOutput(settings, prettyPrint: true);
            DoNotModifyJsonPropertyName(settings);
        }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc().AddJsonOptions(options => {
                ConfigureJsonSerializerSettings(
                    options.SerializerSettings, 
                    this.HostingEnvironment.IsDevelopment());
                }
            );
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "TTB_DWAPIPRODUCT_DP", Version = "v1" });
            });
            this.ConfigureLogicServices(services);
        }

        const int MAX_CONCURRENT_WORKERS = 16;

        public void ConfigureLogicServices(IServiceCollection services)
        {
            services.AddHttpContextAccessor();
            services.AddTTBLogger();
            services.AddSingleton<Logic.Setup>();
            services.AddSingleton<Logic.DataAccess>();
            services.AddSingleton<Logic.Service>();
            services.AddHostedService<Logic.PeriodicCleanUp>();
            services.AddBackgroundQueue(e => {}, MAX_CONCURRENT_WORKERS);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory, Logic.Setup setup)
        {
            setup.StatementPath.ToString();
            app.UseMvc();
            ConfigureSwagger(app, setup);
            loggerFactory.AddTTBLog();
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                loggerFactory.AddConsole();
            }
            app.UseStaticFiles();
        }

        private static void ConfigureSwagger(IApplicationBuilder app, Logic.Setup setup) {
            app.UseSwagger().UseSwaggerUI(c => 
            {
                var endpoint = (setup.Options.BaseURL ?? "/") + "swagger/v1/swagger.json";
                c.SwaggerEndpoint(endpoint, "TTB_DWAPIPRODUCT_DP");
            });
        }

    }
}
