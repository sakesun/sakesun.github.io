﻿using System;
using System.Linq;
using System.Diagnostics;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Net;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Extensions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace TTB.Logging
{
    public class TTBLogger : ILogger
    {
        public const string DIRECTION_INBOUND = "Inbound";
        public const string DIRECTION_OUTBOUND = "Outbound";
        public const string EVENT_OPERATION = "OPERATION";
        public const string EVENT_STATUS_SUCCESS = "SUCCESS";
        public const string EVENT_STATUS_FAIL = "FAIL";
        private readonly ILogger<TTBLogger> logger;
        public TTBLogger(ILogger<TTBLogger> logger)
        {
            this.logger = logger;
        }
        IDisposable ILogger.BeginScope<TState>(TState state)
        {
            return this.logger.BeginScope(state);
        }

        bool ILogger.IsEnabled(LogLevel logLevel)
        {
            return this.logger.IsEnabled(logLevel);
        }

        void ILogger.Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
        {
            this.logger.Log(logLevel, eventId, state, exception, formatter);
        }

        static string LogLevelText(LogLevel level)
        {
            switch (level)
            {
                case LogLevel.Trace: return "TRACE";
                case LogLevel.Debug: return "DEBUG";
                case LogLevel.Information: return "INFO";
                case LogLevel.Warning: return "WARNING";
                case LogLevel.Error: return "ERROR";
                case LogLevel.Critical: return "CRITICAL";
                case LogLevel.None: return "NONE";
            }
            return level.ToString();
        }

        const string DEFAULT_LOG_PART = "-";

        static void CleanLogPart(ref string part, string defaultValue = DEFAULT_LOG_PART)
        {
            var s = part;
            if (string.IsNullOrWhiteSpace(s)) s = defaultValue;
            s = s.Replace(" ", "");
            part = s;
        }

        static void CleanLogMessage(ref string message, string defaultValue = DEFAULT_LOG_PART)
        {
            var s = message;
            if (string.IsNullOrWhiteSpace(s)) s = defaultValue;
            message = s;
        }

        public void TTBLog(LogLevel logLevel, string func, string session, string uuid, string message)
        {
            var thread = Thread.CurrentThread.Name;
            var level = LogLevelText(logLevel);
            CleanLogPart(ref thread);
            CleanLogPart(ref level);
            CleanLogPart(ref func);
            CleanLogPart(ref session);
            CleanLogPart(ref uuid);
            CleanLogMessage(ref message);
            if (thread == DEFAULT_LOG_PART) thread = $"Thread-{Thread.CurrentThread.ManagedThreadId.ToString("00000")}";
            var s = $"{thread} {level} {func} {session} {uuid} - {message}";
            this.Log(logLevel, s);
        }
        void TTBLogPayload(string direction, string func, string session, string uuid, IHeaderDictionary headers, string payload)
        {
            var headerItems = new Dictionary<string, object>();
            if (headers != null)
            {
                foreach (var h in headers)
                {
                    var values = new List<string>(h.Value).ToArray();
                    if (values.Length == 1)
                    {
                        headerItems.Add(h.Key, values[0]);
                    }
                    else
                    {
                        headerItems.Add(h.Key, JsonConvert.SerializeObject(values));
                    }
                }
            }
            var headerText = JsonConvert.SerializeObject(headerItems);
            var message = $"PAYLOAD {direction} {headerText} {payload}";
            this.TTBLog(LogLevel.Information, func, session, uuid, message);
        }
        public void TTBLogInbound(string func, string session, string uuid, IHeaderDictionary headers, string payload)
        {
            this.TTBLogPayload(DIRECTION_INBOUND, func, session, uuid, headers, payload);
        }
        public async Task<T> TTBLogInbound<T>(HttpRequest request, string func, string session, string uuid, string payload, Func<Task<T>> f)
        {
            func = func ?? (request.Path.Value ?? "").Split("/").Last();
            var headers = request.Headers;
            var uri = request.GetDisplayUrl();
            var watch = new Stopwatch();
            watch.Start();
            this.TTBLogInbound(func, session, uuid, headers, payload);
            try
            {
                var r = await f();
                watch.Stop();
                var elapse = Convert.ToInt32(watch.Elapsed.TotalMilliseconds);
                var status = TTBLogger.EVENT_STATUS_SUCCESS;
                try
                {
                    this.TTBLogHttpEvent(func, session, uuid, status, null, (int)HttpStatusCode.OK, elapse, uri);
                }
                catch { }
                return r;
            }
            catch (Exception e)
            {
                if (watch.IsRunning) watch.Stop();
                var elapse = Convert.ToInt32(watch.Elapsed.TotalMilliseconds);
                var status = TTBLogger.EVENT_STATUS_FAIL;
                try
                {
                    var parameters = new Dictionary<string, string>
                    {
                        { "ErrorMessage", e.Message }
                    };
                    this.TTBLogHttpEvent(func, session, uuid, status, parameters, (int)HttpStatusCode.InternalServerError, elapse, uri);
                }
                catch { }
                throw;
            }
        }
        public void TTBLogOutbound(string func, string session, string uuid, IHeaderDictionary headers, string payload)
        {
            this.TTBLogPayload(DIRECTION_OUTBOUND, func, session, uuid, headers, payload);
        }
        public async Task<T> TTBLogOutbound<T>(string func, string session, string uuid, IHeaderDictionary headers, string payload, string uri, Func<Action<int, object>, Task<T>> f)
        {
            func = func ?? (uri ?? "").Split("/").Last();
            var watch = new Stopwatch();
            watch.Start();
            this.TTBLogOutbound(func, session, uuid, headers, payload);
            int httpStatusCode = -1;
            object parameters = null;
            try
            {
                var r = await f((changeStatus, changeParams) => {
                    httpStatusCode = changeStatus;
                    parameters = changeParams;
                });
                watch.Stop();
                var elapse = Convert.ToInt32(watch.Elapsed.TotalMilliseconds);
                var status = TTBLogger.EVENT_STATUS_SUCCESS;
                try
                {
                    if (httpStatusCode == -1) httpStatusCode = (int)HttpStatusCode.OK;
                    this.TTBLogHttpEvent(func, session, uuid, status, parameters, httpStatusCode, elapse, uri);
                }
                catch { }
                return r;
            }
            catch (Exception e)
            {
                if (watch.IsRunning) watch.Stop();
                var elapse = Convert.ToInt32(watch.Elapsed.TotalMilliseconds);
                var status = TTBLogger.EVENT_STATUS_FAIL;
                try
                {
                    if (parameters == null)
                    {
                        parameters = new Dictionary<string, string> {
                            { "ErrorMessage", e.Message }
                        };
                    }
                    if (httpStatusCode == -1) httpStatusCode = (int)HttpStatusCode.InternalServerError;
                    this.TTBLogHttpEvent(func, session, uuid, status, parameters, httpStatusCode, elapse, uri);
                }
                catch { }
                throw;
            }
        }
        static void AddEventValue(Dictionary<string, object> dic, string name, object value)
        {
            if (value != null) dic.Add(name, value);
        }
        public void TTBLogHttpEvent(string func, string session, string uuid, string status, object parameters, int httpReponseCode, int responseTime, string uri)
        {
            var events = new Dictionary<string, object>();
            AddEventValue(events, "event_type", EVENT_OPERATION);
            AddEventValue(events, "status", status);
            AddEventValue(events, "parameters", parameters);
            AddEventValue(events, "http_code", httpReponseCode);
            AddEventValue(events, "responseTime", responseTime);
            AddEventValue(events, "uri", uri);
            var message = $"EVENT { JsonConvert.SerializeObject(events) }";
            this.TTBLog(LogLevel.Information, func, session, uuid, message);
        }
        public void TTBLogError(string func, string session, string uuid, string uri, string errorInfo, string input, string variable)
        {
            if (uri == null) uri = uri ?? func ?? "-";
            errorInfo = errorInfo ?? "-";
            input = input ?? "-";
            variable = variable ?? "-";
            var message = $"ERROR {uri}\n{errorInfo}\n{input} {variable}";
            this.TTBLog(LogLevel.Error, func, session, uuid, message);
        }

        static string GetErrorInfo(Exception e)
        {
            var stacktrace = e.StackTrace.Replace("\n\n", "\n");
            var errorInfo = $"{e.GetType().FullName} \"{e.Message}\"\n{stacktrace}";
            return errorInfo;
        }

        static string GetAllErrorInfo(Exception e)
        {
            var errorInfos = new List<string>();
            while (e != null)
            {
                var errInfo = GetErrorInfo(e);
                errorInfos.Add(errInfo);
                e = e.InnerException;
            }
            return string.Join("\n---InnerException---\n", errorInfos);
        }

        public void TTBLogError(string func, string session, string uuid, string uri, Exception e, object inputs, object variables)
        {
            var errorInfo = GetAllErrorInfo(e);
            string logValue(object x)
            {
                if (x == null) return "-";
                if (x is string s) return s;
                return JsonConvert.SerializeObject(x);
            }
            this.TTBLogError(func, session, uuid, uri, errorInfo, logValue(inputs), logValue(variables));
        }
    }

    public static class TTBLogExtensions
    {
        public const string DEFAULT_LOG4NET_CONFIG = "log4net.config";
        public static IServiceCollection AddTTBLogger(this IServiceCollection services)
        {
            return services.AddTransient<TTBLogger>();
        }
        public static ILoggerFactory AddTTBLog(this ILoggerFactory loggerFactory, string log4NetConfigFile = DEFAULT_LOG4NET_CONFIG)
        {
            return loggerFactory.AddLog4Net(new Log4NetProviderOptions() { Log4NetConfigFileName = log4NetConfigFile });
        }
    }
}
